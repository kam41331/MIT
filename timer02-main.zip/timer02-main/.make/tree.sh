#!/bin/sh

exec tree inc src lib
